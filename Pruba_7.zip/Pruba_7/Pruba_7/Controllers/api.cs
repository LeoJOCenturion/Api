﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using Newtonsoft.Json;
using System.Data.SqlClient;
using Microsoft.SqlServer;




namespace Pruba_7.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class api : Controller
    {
        
        [HttpGet("GetPersona/{tipoDoc}/{nroDoc}")]
        public string GetPersona(string tipoDoc, string nroDoc)
        {
            string connectionString = "Server=172.20.1.165;Persist Security Info=True;Database=DbCmactaux;User Id=dbaccessRo;Password=dbaccessRo2025*;";

            using (Microsoft.Data.SqlClient.SqlConnection connection = new Microsoft.Data.SqlClient.SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    string query = @"
                            SELECT 
                                A.cPersCod AS CodPersona,
                                [dbo].[PstaNombre](p.cPersNombre, 1) AS Nombre
                            FROM PersID A
                            INNER JOIN Persona p ON A.cPersCod = p.cPersCod
                            WHERE A.cPersIDTpo = @cTipDoc AND A.cPersIDnro = @cNroDoc";

                    using (var command = new Microsoft.Data.SqlClient.SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@cTipDoc", tipoDoc);
                        command.Parameters.AddWithValue("@cNroDoc", nroDoc);

                        using (var reader = command.ExecuteReader())
                        {
                            var resultados = new List<object>();

                            while (reader.Read())
                            {
                                resultados.Add(new
                                {
                                    CodPersona = reader["CodPersona"].ToString(),
                                    Nombre = reader["Nombre"].ToString()
                                });
                            }

                            return JsonConvert.SerializeObject(resultados);
                        }
                    }
                }
                catch (Exception ex)
                {
                    return "Error de conexión o consulta: " + ex.Message;
                }
            }
        }

    }
}